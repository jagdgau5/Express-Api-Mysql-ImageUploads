const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Generate unique filename with timestamp and random string
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Check if the file is an image
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// MySQL Database Connection
const dbConfig = {
  host: 'localhost',
  user: 'jio',
  password: 'jio789%#kio',
  database: 'express_api3'
};

// Create connection pool
const pool = mysql.createPool(dbConfig);

// Initialize database and table
async function initializeDatabase() {
  try {
    const connection = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password
    });

    // Create database if it doesn't exist
    await connection.execute(`CREATE DATABASE IF NOT EXISTS ${dbConfig.database}`);
    await connection.end();

    // Create table with profile_image column
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        profile_image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;
    
    await pool.execute(createTableQuery);
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
  }
}

// API Routes

// Get all users
app.get('/api/users', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM users ORDER BY created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Get user by ID
app.get('/api/users/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// Create new user with profile image
app.post('/api/users', upload.single('profile_image'), async (req, res) => {
  try {
    const { name, email } = req.body;
    const profile_image = req.file ? `/uploads/${req.file.filename}` : null;
    
    if (!name || !email) {
      // If there was a file uploaded but validation failed, delete it
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const [result] = await pool.execute(
      'INSERT INTO users (name, email, profile_image) VALUES (?, ?, ?)',
      [name, email, profile_image]
    );

    const [newUser] = await pool.execute('SELECT * FROM users WHERE id = ?', [result.insertId]);
    
    res.status(201).json(newUser[0]);
  } catch (error) {
    console.error('Error creating user:', error);
    
    // If there was a file uploaded but operation failed, delete it
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create user' });
    }
  }
});

// Update user with profile image
app.put('/api/users/:id', upload.single('profile_image'), async (req, res) => {
  try {
    const { name, email } = req.body;
    const userId = req.params.id;
    let profile_image = null;

    if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }

    // First, get the current user to know the existing profile image
    const [currentUser] = await pool.execute('SELECT * FROM users WHERE id = ?', [userId]);
    if (currentUser.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    // If a new file is uploaded, set the new profile image path
    if (req.file) {
      profile_image = `/uploads/${req.file.filename}`;
      // If there was an old profile image, delete it from the filesystem
      if (currentUser[0].profile_image) {
        const oldImagePath = path.join(__dirname, 'public', currentUser[0].profile_image);
        fs.unlink(oldImagePath, (err) => {
          if (err) console.error('Error deleting old image:', err);
        });
      }
    } else {
      // Keep the existing profile image if no new file is uploaded
      profile_image = currentUser[0].profile_image;
    }

    const [result] = await pool.execute(
      'UPDATE users SET name = ?, email = ?, profile_image = ? WHERE id = ?',
      [name, email, profile_image, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const [updatedUser] = await pool.execute('SELECT * FROM users WHERE id = ?', [userId]);
    
    res.json(updatedUser[0]);
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// Delete user
app.delete('/api/users/:id', async (req, res) => {
  try {
    // First, get the user to know the profile image path
    const [user] = await pool.execute('SELECT * FROM users WHERE id = ?', [req.params.id]);
    if (user.length > 0 && user[0].profile_image) {
      const imagePath = path.join(__dirname, 'public', user[0].profile_image);
      // Delete the profile image from the filesystem
      fs.unlink(imagePath, (err) => {
        if (err) console.error('Error deleting image:', err);
      });
    }

    const [result] = await pool.execute('DELETE FROM users WHERE id = ?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware for multer
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'File too large. Maximum size is 5MB.' });
    }
  } else if (error) {
    return res.status(400).json({ error: error.message });
  }
  next();
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('Make sure your MySQL server is running and database credentials are correct');
  });
}

startServer().catch(console.error);
